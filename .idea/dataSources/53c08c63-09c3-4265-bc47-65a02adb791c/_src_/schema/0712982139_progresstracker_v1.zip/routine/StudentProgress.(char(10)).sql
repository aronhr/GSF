CREATE PROCEDURE StudentProgress(IN sID CHAR(10))
  BEGIN
    SELECT Tracks.trackName, sum(Courses.courseCredits) as totalCredits
    FROM StudentCourses
    INNER JOIN Courses
    ON StudentCourses.courseNumber = Courses.courseNumber
	INNER JOIN TrackCourses
    ON Courses.courseNumber = TrackCourses.courseNumber
	INNER JOIN Tracks
    ON TrackCourses.trackID = Tracks.trackID
    INNER JOIN Students
    ON Students.studentID = StudentCourses.studentID
    WHERE StudentCourses.grade >= 5 AND StudentCourses.studentID = sID
    GROUP BY Tracks.trackName;
END;

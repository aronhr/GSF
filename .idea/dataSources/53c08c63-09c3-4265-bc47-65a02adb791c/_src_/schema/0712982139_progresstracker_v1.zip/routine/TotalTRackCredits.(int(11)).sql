CREATE FUNCTION TotalTRackCredits(track_ID INT)
  RETURNS INT
  BEGIN
    RETURN(SELECT COUNT(*) FROM TrackCourses WHERE trackID = track_ID);
END;

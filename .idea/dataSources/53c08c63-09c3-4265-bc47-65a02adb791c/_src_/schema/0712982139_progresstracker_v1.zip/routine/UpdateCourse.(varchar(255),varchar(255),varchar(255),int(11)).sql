CREATE PROCEDURE UpdateCourse(IN old_course_Number VARCHAR(255), IN course_Number VARCHAR(255),
                              IN course_Name       VARCHAR(255), IN course_Credits INT)
  BEGIN
  UPDATE  0712982139_progresstracker_v1.courses SET  courseNumber =  course_Number, courseName =  course_Name, courseCredits = course_Credits  WHERE  courses.courseNumber =  old_course_Number;
END;

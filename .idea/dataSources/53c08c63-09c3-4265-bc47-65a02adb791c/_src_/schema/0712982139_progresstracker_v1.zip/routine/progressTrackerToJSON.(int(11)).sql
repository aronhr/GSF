CREATE FUNCTION progressTrackerToJSON(semID INT)
  RETURNS JSON
  BEGIN
	DECLARE stu_studentID char(10); -- kennitala
	DECLARE stu_studentName varchar(255);
	DECLARE v_finished INTEGER DEFAULT 0;
    DECLARE cur_course char(10);
    DECLARE stu_trackID int;
    DECLARE sem_name char(10);
    DECLARE student_courses JSON;
    DECLARE student_info JSON;

    DECLARE j JSON;

	DEClARE json_cursor CURSOR FOR
		SELECT studentID, studentName, trackID FROM Students;

	DEClARE course_cursor CURSOR FOR
		SELECT courseNumber FROM StudentCourses
			WHERE studentID = stu_studentID AND semesterID = semID;

	-- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER
		FOR NOT FOUND SET v_finished = 1;
	SET sem_name = (SELECT semesterName FROM Semesters WHERE semesterID = semID);
	SET j = JSON_OBJECT('semester', JSON_OBJECT('name', sem_name, 'students', JSON_ARRAY()));
	OPEN json_cursor;
		json_loop: LOOP
			FETCH json_cursor INTO stu_studentID, stu_studentName, stu_trackID;
			IF v_finished = 1 THEN
				LEAVE json_loop;
			END IF;
            SET student_courses = JSON_ARRAY();
			OPEN course_cursor;
				courses_loop: LOOP
					FETCH course_cursor INTO cur_course;

					IF v_finished = 1 THEN
						SET v_finished = 0;
						LEAVE courses_loop;
					END IF;
                    SET student_courses = JSON_ARRAY_APPEND(student_courses, '$', cur_course);
				END LOOP courses_loop;
			CLOSE course_cursor;

			SET student_info = JSON_OBJECT('ID', stu_studentID, 'studentName', stu_studentName,
            'trackID', stu_trackID, 'courses', student_courses);
            SET j = JSON_ARRAY_APPEND(j, '$.semester.students', student_info);
        END LOOP json_loop;
	CLOSE json_cursor;
    RETURN(j);
END;

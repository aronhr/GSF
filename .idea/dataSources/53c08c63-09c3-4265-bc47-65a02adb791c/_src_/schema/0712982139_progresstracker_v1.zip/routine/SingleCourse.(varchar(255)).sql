CREATE PROCEDURE SingleCourse(IN course_Number VARCHAR(255))
  BEGIN
  SELECT * FROM `0712982139_progresstracker_v1`.courses WHERE courseNumber = course_Number;
END;

CREATE FUNCTION HighestCredits()
  RETURNS INT
  BEGIN
    RETURN(SELECT MAX(courseCredits) FROM Courses);
END;

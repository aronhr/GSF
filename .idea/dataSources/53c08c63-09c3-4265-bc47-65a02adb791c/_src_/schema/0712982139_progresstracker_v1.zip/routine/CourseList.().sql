CREATE PROCEDURE CourseList()
  BEGIN
  SELECT * FROM `0712982139_progresstracker_v1`.courses;
END;

CREATE FUNCTION leastRestrictedCourseNumber()
  RETURNS INT
  BEGIN
    RETURN(SELECT COUNT(*) AS Course_Count FROM Restrictors GROUP BY courseNumber ORDER BY Course_Count ASC LIMIT 1);
END;

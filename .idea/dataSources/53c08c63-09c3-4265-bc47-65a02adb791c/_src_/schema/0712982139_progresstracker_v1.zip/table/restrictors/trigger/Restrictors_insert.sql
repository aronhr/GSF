CREATE TRIGGER Restrictors_insert
BEFORE INSERT ON restrictors
FOR EACH ROW
  BEGIN
	IF NEW.courseNumber = NEW.restrictorID THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Ekki er haegt ad skra i gagnagrunn. courseNumber og RestrictorID er sami kúrsinn';
    END IF;
END;

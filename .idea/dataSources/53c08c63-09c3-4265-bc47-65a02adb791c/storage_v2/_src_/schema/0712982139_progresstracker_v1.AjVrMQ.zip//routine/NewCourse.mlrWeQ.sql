CREATE PROCEDURE NewCourse(IN course_Number VARCHAR(255), IN course_Name VARCHAR(255), IN course_Credits INT)
  BEGIN
 #INSERT INTO `0712982139_progresstracker_v1`.`courses` (`courseNumber`, `courseName`, `courseCredits`) VALUES ('STÆ555', 'Stærðfræði', '3');
  INSERT INTO `0712982139_progresstracker_v1`.courses (courseNumber, courseName, courseCredits) VALUES (course_Number, course_Name, course_Credits);
END;


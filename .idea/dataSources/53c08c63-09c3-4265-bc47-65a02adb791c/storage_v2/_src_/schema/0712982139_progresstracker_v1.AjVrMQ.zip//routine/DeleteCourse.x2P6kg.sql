CREATE PROCEDURE DeleteCourse(IN course_Number VARCHAR(255))
  BEGIN
 DELETE FROM 0712982139_progresstracker_v1.courses WHERE courses.courseNumber = course_Number;
END;


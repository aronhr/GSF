CREATE PROCEDURE ElectedCourses(IN s_studentID INT)
  BEGIN
		SELECT courseNumber, courseName, courseCredits
      FROM courses
        WHERE NOT EXISTS
          (SELECT courseNumber
            FROM studentcourses
              WHERE studentcourses.courseNumber = courses.courseNumber AND studentcourses.studentID = s_studentID )ORDER BY RAND() LIMIT 5 ;
	END;


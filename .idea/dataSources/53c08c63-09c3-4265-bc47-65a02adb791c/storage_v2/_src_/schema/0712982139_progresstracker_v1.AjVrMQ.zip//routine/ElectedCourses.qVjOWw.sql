CREATE PROCEDURE ElectedCourses(IN s_studentID INT)
  BEGIN

  DECLARE fails INT ;
  DECLARE courseLimit INT ;

  # Ath ef nemandi hafi fallið á önn
  SET fails = (SELECT COUNT(courseNumber)
                      FROM studentcourses
                        JOIN students ON students.studentID = studentcourses.studentID
                          WHERE studentcourses.grade <= 4
                            AND studentcourses.semesterID = (students.semester_ID - 1)
                              AND students.studentID = s_studentID);

# Ef nemandi féll í 5 eða fleiri fögum fær hann ekki að skrá sig á næstu önn
IF(fails >= 5) THEN
	SET courseLimit = 0;
  SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Nemandi féll á önn. Nemandi hefur ekki heimild til að skrá sig á næstu önn.';
    END IF;

# Ef nemandi féll í 4 eða færri fögum fær hann 5 áfanga á næstu önn
IF(fails < 5) THEN
	SET courseLimit = 6;
    END IF;

# Nær í courseNumber, courseName og courseCredits og byrtir ekki áfanga sem nemandi hefur náð.
# Ef nemandi hefur fengið 4 eða lægra í áfanga byrtist hann aftur í þessari skipun þar sem nemandi náði ekki áfanganum.
SELECT courseNumber, courseName, courseCredits
     FROM courses
       WHERE NOT EXISTS
         (SELECT courseNumber
           FROM studentcourses
             WHERE studentcourses.courseNumber = courses.courseNumber AND studentcourses.grade >= 5 AND studentcourses.studentID = s_studentID )ORDER BY RAND() LIMIT courseLimit;


END;


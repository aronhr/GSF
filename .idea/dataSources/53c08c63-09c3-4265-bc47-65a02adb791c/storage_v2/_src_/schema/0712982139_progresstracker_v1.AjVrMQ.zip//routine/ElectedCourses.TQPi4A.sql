CREATE PROCEDURE ElectedCourses(IN s_studentID INT, IN studentid INT)
  BEGIN
  DECLARE countFails INT ;
  DECLARE maxlimit INT ;

  SET countFails = (SELECT COUNT( courseNumber )
                      FROM studentcourses
                        JOIN students ON students.studentID = studentcourses.studentID
                          WHERE studentcourses.grade <=4
                            AND studentcourses.semesterID = students.semester_ID
                              AND students.studentID = studentid);

IF(countFails >= 5) then
	SET maxlimit = 0;
  SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Nemandi féll á seinustu önn. Nemandi hefur ekki heimild til að skrá sig á næstu önn.';
    end IF;

IF(countFails <= 0) THEN
	set maxlimit = 5;
    end IF;


SELECT courseNumber, courseName, courseCredits
     FROM courses
       WHERE NOT EXISTS
         (SELECT courseNumber
           FROM studentcourses
             WHERE studentcourses.courseNumber = courses.courseNumber AND studentcourses.studentID = s_studentID )ORDER BY RAND() LIMIT maxlimit;


END;

